Node.js example chat server

To run example do:

1. Install node.js
2. Create new directory for app
3. Place index.html, server.js and package.json in directory
4. In command line go to directory then: npm install
5. In command line do: node server
6. In browser go to localhost:3000