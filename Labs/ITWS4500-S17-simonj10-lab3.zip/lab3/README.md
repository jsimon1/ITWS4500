Jeremy Simon - Lab 3

PART 1:
Github Repo: https://github.com/jsimon1/ITWS4500
Bug tracking configuration: config.ini
Bug tracking screenshot: localBugInstance.png, localBugInterface.png

PART 2:
Project server: websci.w1bbb.com(You may SSH onto the server, logins are your first name for user and pass)
Our project is going to be a streamlined menu design app that is deployable to Rasperry Pis and can be used by restaurants to display a dynamic menu on a TV. The user would be able to edit their menu in a web browser using JQuery responsiveness to help keep everything aligned and gives the user an opportunity to make their menu unique.
Group project repo: https://github.com/ddbruce/websci-group-2
Group project bug tracker: https://waffle.io/ddbruce/websci-group-2
Screenshot of bug tracker: groupBugTracker.png